from django.apps import AppConfig


class ApiRegisterConfig(AppConfig):
    name = 'api_registration'
